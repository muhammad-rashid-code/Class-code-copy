"use client";

import { signUpUserWithEmailAndPassword } from "@/firebase/firebaseauth";
import Link from "next/link";
import { useState } from "react";

export default function SignUp() {
  const [emailSiUsPLog, setEmailSiUsPLog] = useState<string>("");
  const [passwordSiUsPLog, setPasswordSiUsPLog] = useState<string>("");
  return (
    <>
      <h1>mybook</h1>
      <p>mybook helps you connect and share with the people in your life.</p>
      <div style={{ border: "1px solid black" }}>
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          id="email"
          placeholder="Email address or Phone number"
          value={emailSiUsPLog}
          onChange={(e) => setEmailSiUsPLog(e.target.value)}
        />
        <br />
        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          placeholder="Password"
          value={passwordSiUsPLog}
          onChange={(e) => setPasswordSiUsPLog(e.target.value)}
        />
      </div>
      <br />
      <button
        onClick={() => {
          signUpUserWithEmailAndPassword(emailSiUsPLog, passwordSiUsPLog);
        }}
      >
        Sing Up
      </button>
      <p>
        Have an Account <Link href={"/"}>Login</Link>
      </p>
    </>
  );
}
