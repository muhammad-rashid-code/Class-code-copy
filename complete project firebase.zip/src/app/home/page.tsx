"use client";

import { AuthContextExport } from "@/context/authcontext";
import { lognOut } from "@/firebase/firebaseauth";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
// import { useEffect } from "../verify-email/page";

export default function HomeComponent() {
  const { user } = AuthContextExport()!;
  const route = useRouter();
  return (
    <>
      <h1>Welcome mybook</h1>
      <p>mybook helps you connect and share with the people in your life.</p>
      <h1>
        welcome{" "}
        <span style={{ backgroundColor: "greenyellow" }}>
          {user?.email?.split("@")[0]}
        </span>{" "}
        to <b>mybook</b>
      </h1>
      {/* {useEffect(() => {
if (!user?.emailVerified && user?.uid) {
route.push("../verify-email/page");
}
}, [])} */}
      <button
        onClick={() => {
          lognOut();
        }}
      >
        Log Out
      </button>
    </>
  );
}
