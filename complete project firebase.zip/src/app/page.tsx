// Root page as src/page.tsx
"use client";

import { logInInWithEmailAndPassword } from "@/firebase/firebaseauth";
import Link from "next/link";
import { useState } from "react";

export default function Home() {
  const [emailSiUsP, setEmailSiUsP] = useState<string>("");
  const [passwordSiUsP, setPasswordSiUsP] = useState<string>("");
  return (
    <>
      <h1>mybook</h1>
      <p>mybook helps you connect and share with the people in your life.</p>
      <div style={{ border: "1px solid black" }}>
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          id="email"
          placeholder="Email address or Phone number"
          value={emailSiUsP}
          onChange={(e) => setEmailSiUsP(e.target.value)}
        />
        <br />
        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          placeholder="Password"
          value={passwordSiUsP}
          onChange={(e) => setPasswordSiUsP(e.target.value)}
        />
      </div>
      <br />
      <button
        onClick={() => {
          logInInWithEmailAndPassword(emailSiUsP, passwordSiUsP);
        }}
      >
        Login
      </button>
      <p>
        <strong>
          <Link href={"./forgotPassword"}>Forgotten password</Link>
        </strong>
      </p>
      <p>
        <strong>
          <Link href={"./sign-up"}>Create new account</Link>
        </strong>
      </p>
    </>
  );
}
