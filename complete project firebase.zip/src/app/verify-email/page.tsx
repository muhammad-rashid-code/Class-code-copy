"use client";

import { lognOut } from "@/firebase/firebaseauth";

export default function VerifyEmail() {
  return (
    <>
      <h1>VerifyEmail</h1>
      <button
        onClick={() => {
          lognOut();
        }}
      >
        Log Out
      </button>
    </>
  );
}
