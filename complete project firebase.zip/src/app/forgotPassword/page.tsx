"use client";
import { AuthContextExport } from "@/context/authcontext";
import { sendPasswordReset, updateUserPassword } from "@/firebase/firebaseauth";
import { useState } from "react";
// import { AuthContextExport } from "@/context/AuthContextFunc";
// const {} = AuthContextExport();
export default function ForgotPassword() {
  //   const {} = AuthContextExport();
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    try {
      await sendPasswordReset(email);
      setMessage("Password reset email sent. Please check your inbox.");
      setError("");
    } catch (error) {
      setMessage("");
      setError("Failed to send password reset email. Please try again.");
    }
  };

  return (
    <>
      <h1>Forgot Password</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Email:
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </label>
        <button type="submit">Send Password Reset Email</button>
      </form>
      {message && <p>{message}</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}
    </>
  );
}
