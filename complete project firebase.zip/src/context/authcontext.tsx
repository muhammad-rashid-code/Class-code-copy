"use client";

import { sendPasswordReset, updateUserPassword } from "@/firebase/firebaseauth";
import { app } from "@/firebase/firebaseconfig";
import { getAuth, onAuthStateChanged, updatePassword } from "firebase/auth";
import { useRouter } from "next/navigation";
const auth = getAuth(app);
import { createContext, useContext, useEffect, useState } from "react";

type UserType = {
  email: string | null;
  uid: string;
  emailVerified?: boolean | null;
};

type AuthContextCreateType = {
  user: UserType | null;
  sendPasswordReset: (email: string) => Promise<void>;
  updatePassword: (newPassword: string) => Promise<void>;
};

const AuthContextCreate = createContext<AuthContextCreateType | null>(null);

type AuthContextFuncType = { children: React.ReactNode };

export default function AuthContextFunc({ children }: AuthContextFuncType) {
  const [userCuS, setUserCuS] = useState<UserType | null>(null);
  const route = useRouter();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (loggedInUser) => {
      if (loggedInUser) {
        const { email, uid, emailVerified } = loggedInUser;
        setUserCuS({ email, uid, emailVerified });

        if (emailVerified) {
          route.push("/home"); // Use absolute path instead of relative path
        } else {
          route.push("/verify-email"); // Use absolute path
        }
      } else {
        setUserCuS(null);
        route.push("/"); // Redirect to the home page if not authenticated
      }
    });

    // Clean up subscription on component unmount
    return () => unsubscribe();
  }, [route]);
  const handleSendPasswordReset = async (email: string) => {
    try {
      await sendPasswordReset(email);
      // Handle success, e.g., show a success message to the user
    } catch (error) {
      // Handle error, e.g., show an error message to the user
    }
  };

  const handleUpdatePassword = async (newPassword: string) => {
    try {
      await updateUserPassword(newPassword); // No need to pass user here
      // Handle success, e.g., show a success message to the user
    } catch (error) {
      // Handle error, e.g., show an error message to the user
    }
  };

  return (
    <AuthContextCreate.Provider
      value={{
        user: userCuS,
        sendPasswordReset: handleSendPasswordReset,
        updatePassword: handleUpdatePassword,
      }}
    >
      {children}
    </AuthContextCreate.Provider>
  );
}

export const AuthContextExport = () => useContext(AuthContextCreate);
