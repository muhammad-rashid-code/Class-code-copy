// src/firebase/firebaseauth.ts

import {
  createUserWithEmailAndPassword,
  getAuth,
  sendEmailVerification,
  signInWithEmailAndPassword,
  signOut,
  updatePassword,
  sendPasswordResetEmail, // Import this function
  User as FirebaseUser,
} from "firebase/auth";
import { app } from "./firebaseconfig";

// Initialize Firebase Auth
const auth = getAuth(app);

// User sign up service function using Firebase
export function signUpUserWithEmailAndPassword(
  email: string,
  password: string
) {
  createUserWithEmailAndPassword(auth, email, password)
    .then(async (userCredential) => {
      const user = userCredential.user;
      const { email, uid } = user;
      console.log(email, uid, "User account created in firebaseAuth.ts");

      // Send email verification
      await sendEmailVerification(user);
      console.log("Verification email sent.");
    })
    .catch((error) => {
      console.error("Error signing up:", error.code, error.message);
    });
}

// User sign in service function using Firebase
export function logInInWithEmailAndPassword(email: string, password: string) {
  signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      const { email, uid } = userCredential.user;
      console.log(email, uid, "User logged in firebaseAuth.ts");
    })
    .catch((error) => {
      console.error("Error logging in:", error.code, error.message);
    });
}

// User log out service function using Firebase
export function lognOut() {
  signOut(auth)
    .then(() => {
      console.log("User signed out.");
    })
    .catch((error) => {
      console.error("Error signing out:", error.code, error.message);
    });
}

// Function to send a verification email to the current user
export function sendVerificationEmail() {
  const user = auth.currentUser;
  if (user) {
    sendEmailVerification(user)
      .then(() => {
        console.log("Verification email sent.");
      })
      .catch((error) => {
        console.error(
          "Error sending verification email:",
          error.code,
          error.message
        );
      });
  } else {
    console.log("No user is currently signed in.");
  }
}

// Function to update the password for the current user
export async function updateUserPassword(newPassword: string) {
  const user = auth.currentUser;
  if (user) {
    try {
      await updatePassword(user, newPassword);
      console.log("Password updated successfully.");
    } catch (error) {
      console.error("Error updating password:", error.code, error.message);
    }
  } else {
    console.log("No user is currently signed in.");
  }
}

// Function to send a password reset email
export async function sendPasswordReset(email: string) {
  try {
    await sendPasswordResetEmail(auth, email);
    console.log("Password reset email sent.");
  } catch (error) {
    console.error(
      "Error sending password reset email:",
      error.code,
      error.message
    );
  }
}
